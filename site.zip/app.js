// Поиск и вкладки каталога прямо на странице (без сервера): фильтруем карточки по словам и разделу.
(function () {
  const q = document.getElementById("q");
  const cards = Array.from(document.querySelectorAll(".card"));
  const tabs = Array.from(document.querySelectorAll(".tab"));
  const count = document.querySelector(".count");
  const nothing = document.querySelector(".nothing");
  let kind = "all";

  function apply() {
    const words = (q.value || "").toLowerCase().split(/\s+/).filter(Boolean);
    let shown = 0;
    for (const card of cards) {
      const okKind = kind === "all" || card.dataset.kind === kind;
      const text = card.dataset.search;
      // Слово засчитываем и по началу («скачат» найдёт «скачать»), чтобы окончания не мешали.
      const okText = words.every((w) => text.includes(w) || text.includes(w.slice(0, Math.max(4, w.length - 2))));
      const show = okKind && okText;
      card.hidden = !show;
      if (show) shown++;
    }
    count.textContent = count.dataset.template.replace("{n}", shown);
    nothing.hidden = shown !== 0;
  }

  q.addEventListener("input", apply);
  for (const tab of tabs) {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.toggle("active", t === tab));
      kind = tab.dataset.kind;
      apply();
    });
  }
})();
